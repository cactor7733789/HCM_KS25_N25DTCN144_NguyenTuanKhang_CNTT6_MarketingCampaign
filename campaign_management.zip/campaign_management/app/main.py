from fastapi import FastAPI

from app.db.database import engine, Base

from app.models.user import User  
from app.models.campaign import Campaign ,CampaignMember   
from app.models.campaign_task import CampaignTask

from app.routers.auth import router as router
from app.routers.users import router as users_router
from app.routers.campaign import router as campaign_rt

app = FastAPI(
    title="Marketing Campaign Management API",
    version="1.0.0"
)

app.include_router(router)
app.include_router(users_router)
app.include_router(campaign_rt)


Base.metadata.create_all(bind=engine)

@app.get("/")
def root():
    return {"message": "Chào mừng đến với API Marketing Campaign Management"}

@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "database": "connected"
    }

